<?php
require "conn.php";
require("PHPMailer-master/PHPMailerAutoload.php");

$effH = $_POST["effH"];
$effF = $_POST["effF"];
$lvl = $_POST["lvl"];
$retardStr = $_POST["retard"];
$obs = $_POST["obs"];
$idagent=$_POST["idAgent"];
$equipement=$_POST["gyms"]; 
$datejour=date("Y-m-d");
$heurepsg='20:00:00';//date("H:i:s");
if($retardStr="true"){
	$retard="1";
}else{
	$retard="0";
}
$association=$_POST['association'];
$to="vitoroliveiraalmeida97@outlook.com";
$from="equipementssportifsmontreuil@gmail.com";
$caseeff=$_POST['caseeff'];
$caseobs=$_POST['caseobs'];

if($caseobs=="true"){
	$subject='Observation '.$lvl.' gymnase '.$equipement;
	$msg="Bonjour,\nJe vous reporte un probleme ".$lvl." sur le gymnase ".$equipement." :\n".$obs;
	$result = smtpMailer($to,$from,'Agent Numero :'.$idagent , $subject , $msg);
}
if ($caseeff=="true"){
	$subject='effectif anormal pour l\'association : '.$association;
	$msg="Bonjour,\nJe vous reporte un effectif anormal releve pour l'association ".$association." sur le gymnase ".$equipement." a ".$heurepsg."h le ".$datejour;
	$result2 = smtpMailer($to,$from,'Agent Numero :'.$idagent , $subject , $msg);
}
$mysql_qry = "INSERT INTO `releve`(`jour`, `heure_de_passage`, `observation`, `effectif_releve_homme`,
 `effectif_releve_femme`, `lvl_observation`, `id_agent`, `nom_equipement`, `retard`) VALUES ('".$datejour."', '".$heurepsg."', '".$obs."', ".$effH.", ".$effF.", '".$lvl."', ".$idagent.", '".$equipement."',".$retard.")";
//echo($datejour.", ".$heurepsg.", ".$obs.", ".$effH.", ".$effF.", ".$lvl.", ".$idagent.", ".$equipement.",".$retard);
 $result = mysqli_query($conn ,$mysql_qry);

function smtpMailer($to, $from, $from_name, $subject, $body) {
	$mail = new PHPMailer();  // Cree un nouvel objet PHPMailer
	$mail->IsSMTP(); // active SMTP
	$mail->SMTPDebug = 0;  // debogage: 1 = Erreurs et messages, 2 = messages seulement
	$mail->SMTPAuth = true;  // Authentification SMTP active
	$mail->SMTPSecure = 'ssl'; // Gmail REQUIERT Le transfert securise
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 465;
	$mail->Username = 'equipementssportifsmontreuil@gmail.com';
	$mail->Password = 'reserterre';
	$mail->SetFrom($from, $from_name);
	$mail->Subject = $subject;
	$mail->Body = $body;
	$mail->AddAddress($to);
	if(!$mail->Send()) {
		return 'Mail error: '.$mail->ErrorInfo;
	} 
	else {
		return true;
	}
}
?>