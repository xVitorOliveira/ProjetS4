<?php
$server_name = "localhost";
$mysql_username="root";
$mysql_password="";
$mysql_db_name="reserterre";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $mysql_db_name);
?>