<?php
require "conn.php";
require("PHPMailer-master/PHPMailerAutoload.php");
$jour =$_POST["jour"];
$heure_passage =$_POST["heure_de_passage"];
$observation =$_POST["obs"];
$image =$_POST["image"];
$heure_arriver =$_POST["heure_arriver"];
$heure_depart =$_POST["heure_depart"];
$effectif_releve =$_POST["effectif_releve"];
$signature =$_POST["signature"];
$lvl_observation =$_POST["lvl_observation"];
$id_agent =$_POST["idAgent"];
$nom_equipement=$_POST["gyms"];
$association=$_Post['association'];
$to="vitoroliveiraalmeida97@outlook.com";
$from="equipementssportifsmontreuil@gmail.com";
$case=$_POST['case'];

if($case=="observationCase"){
	$subject='Observation '.$lvl_observation.' gymnase '.$nom_equipement;
	$msg="Bonjour,\nJe vous reporte un probleme ".$lvl_observation." sur le gymnase ".$nom_equipement." :\n".$observation;
	$result = smtpMailer($to,$from,'Agent Numero :'.$id_agent , $subject , $msg);
	echo("KEK 1");
}
if ($case=="effectifanormal"){
	$subject='effectif anormal pour l\'association : '.$association;
	$msg="Bonjour,\nJe vous reporte un effectif anormal releve pour l'association ".$association." sur le gymnase ".$nom_equipement." de ".$heure_depart."h a ".$heure_arriver."h le ".$jour;
	$result2 = smtpMailer($to,$from,'Agent Numero :'.$id_agent , $subject , $msg);
	echo("KEK 2");
}

$mysql_qry = 'INSERT INTO `releve`(`jour`, `heure_de_passage`, `observation`, `image`, `heure_arriver`, `heure_depart`, `effectif_releve`, `signature`, `lvl_observation`, `id_agent`, `nom_equipement`) VALUES ($jour,$heure_passage,$observation,$image,$heure_arriver,$heure_depart,$effectif_releve,$signature,$lvl_observation,$id_agent,$nom_equipement)';
mysqli_query($conn ,$mysql_qry);

function smtpMailer($to, $from, $from_name, $subject, $body) {
	$mail = new PHPMailer();  // Cree un nouvel objet PHPMailer
	$mail->IsSMTP(); // active SMTP
	$mail->SMTPDebug = 0;  // debogage: 1 = Erreurs et messages, 2 = messages seulement
	$mail->SMTPAuth = true;  // Authentification SMTP active
	$mail->SMTPSecure = 'ssl'; // Gmail REQUIERT Le transfert securise
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 465;
	$mail->Username = 'equipementssportifsmontreuil@gmail.com';
	$mail->Password = 'reserterre';
	$mail->SetFrom($from, $from_name);
	$mail->Subject = $subject;
	$mail->Body = $body;
	$mail->AddAddress($to);
	if(!$mail->Send()) {
		return 'Mail error: '.$mail->ErrorInfo;
	} 
	else {
		return true;
	}
}
?>