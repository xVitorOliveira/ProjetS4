package com.example.voliveira.reserterre;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private Button mBtLaunchActivity;
    private EditText inputUser;
    private EditText inputPassword;
    private BDmanager bdManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBtLaunchActivity = (Button) findViewById(R.id.bt_launch_activity);
        inputUser = (EditText) findViewById(R.id.input_user);
        inputPassword = (EditText) findViewById(R.id.input_password);
        Log.d("CEST BON","try");
        try {
            bdManager = new BDmanager();
            Log.d("test", "here: ");

            mBtLaunchActivity.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    launchActivity();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    protected void verifyConnection()  {
        //On récupère ce qui a été entré dans les EditText
        String user = inputUser.getText().toString();
        String password = inputPassword.getText().toString();

        if(bdManager.Connexion(user, password)){
            launchActivity();
            Log.d("CEST BON","launchAcvt");
        }
        else{
            Log.d("CEST BON","merde");
            inputPassword.setText("");
            Toast.makeText(getApplicationContext(), "Identifiant ou mot de passe invalide! Verifier vos informations de connexions", Toast.LENGTH_SHORT).show();
        }
    }

    private void launchActivity() {
        Log.d("CEST BON","cest bon");
        Intent intent = new Intent(this, select_activity.class);
        startActivity(intent);
    }
}
