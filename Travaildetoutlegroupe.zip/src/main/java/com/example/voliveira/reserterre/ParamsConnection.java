package com.example.voliveira.reserterre;

/**
 * Created by voliveira on 15/03/17.
 */

public class ParamsConnection {
    private String url, pwd, user;

    public String getUrl() {
        return url;
    }

    public String getPwd() {
        return pwd;
    }

    public String getUser() {
        return user;
    }

    public ParamsConnection(){
        url="mysql:host=localhost;dbname=dutinfopw201629";
        pwd="nedyjunu";
        user="dutinfopw201629";
    }
}