package com.example.voliveira.reserterre;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by voliveira on 15/03/17.
 */

public class BDmanager {


    private Connection connexion;

    public BDmanager() throws IOException {
        try {
            ParamsConnection p = new ParamsConnection();
            System.out.println("p => " + p.getUrl());
            connexion = DriverManager.getConnection(p.getUrl(), p.getUser(), p.getPwd());
            //co.createStatement() co.prepareStatement(sql)
            //co.createStatement().executeQuery(sql)
            //methodeQ3(connexion);

        } catch (SQLException e) {
            System.err.println(e);
            throw new IOException("Erreur de connexion a la BD. Désolé");
        }
    }

    public boolean Connexion(String user, String pwd)  {

        ResultSet resultats;
        PreparedStatement requete = null;
        try {
            requete = connexion.prepareStatement("SELECT * FROM Agents WHERE login=? and mdp=?");

            requete.setString(1, user);
            requete.setString(1, pwd);

            resultats = requete.executeQuery();

            return resultats.next();

        } catch (SQLException e) {
            return false;
        }


    }






}